# Naskah Produksi Siap Baca (VO, Dialog & Aksi Konkret) — Paradoks Layanan Tanpa Kertas: Mengapa Aplikasi Publik Masih Minta Fotokopi?

## B01 · `SEQ_01/SCN_01` · `0.0s – 12.0s` (domestic_wake_or_threshold_hook)
- **Narasi VO (Bahasa Indonesia)**: Kamu bangun pagi dengan niat sederhana: mengurus satu surat keterangan yang katanya sudah seratus persen berbasis aplikasi digital tanpa kertas.
- **Dialog `char_dimas_citizen`** *(optimis tipis sambil melirik jam dinding)*: " Katanya cukup lewat ponsel, tapi jaga-jaga tetap bawa lem dan map biru."
- **Catatan Humor Situasional**: Dimas merapikan map plastik tebal padahal spanduk layanan menjanjikan bebas kertas.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · establishing]` **Dimas duduk di tepi kasur kamar di samping jam dinding** — Dimas bangkit dari kasur berlapis rapi saat cahaya pagi menembus jendela kamar lalu meraih map dokumen di atas meja kayu.
  2. `[BLENDER · medium]` **Dimas membuka pintu kayu kamar menuju jalan lingkungan** — Tangan Dimas memutar gagang pintu kayu dan melangkah keluar menuju halaman berteduh pohon hijau.

## B02 · `SEQ_02/SCN_02` · `12.0s – 28.0s` (everyday_friction_and_diegetic_scoreboard)
- **Narasi VO (Bahasa Indonesia)**: Begitu tiba di loket gedung layanan terpadu, petugas ramah menunjuk layar antrean digital, lalu tetap meminta fotokopi bukti tangkapan layar aplikasi rangkap tiga berstempel basah.
- **Dialog `char_sari_clerk`** *(sopan datar penuh prosedur)*: "Kode digitalnya sudah masuk sistem, Kak, sekarang tinggal difotokopi tiga lembar untuk arsip meja sebelah."
- **Catatan Humor Situasional**: Layar 'LAYANAN TANPA KERTAS' berdiri persis di sebelah tumpukan buku berkas setinggi lampu meja.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · wide]` **Gedung layanan publik bertingkat dan mobil parkir di tepi jalan** — Kamera meluncur melewati kendaraan kota dan pohon peneduh menuju fasad gedung layanan terpadu yang rapi.
  2. `[BLENDER · medium]` **Petugas loket Sari di balik meja kayu penuh buku arsip** — Sari duduk tegak di kursi kerja sambil menunjuk tumpukan buku arsip tebal di samping lampu meja.
  3. `[THREEJS · cutaway]` **Papan perbandingan 3D jumlah aplikasi vs jumlah meja verifikasi** — Pedestal tiga dimensi di dalam ruang tunggu menumbuhkan kolom jumlah aplikasi baru berdampingan dengan kolom fotokopi berkas yang tak ikut turun.

## B03 · `SEQ_03/SCN_03` · `28.0s – 44.0s` (systemic_interoperability_insight)
- **Narasi VO (Bahasa Indonesia)**: Masalahnya bukan pada kurangnya aplikasi, melainkan ribuan portal instansi yang berjalan sendiri-sendiri tanpa pertukaran data terpadu, sehingga warga kembali menjadi kurir dokumen antar-meja.
- **Catatan Humor Situasional**: Dimas memindah buku catatan yang persis sama dari lemari kiri ke meja kanan sejauh satu meter.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · wide]` **Lemari arsip terpisah yang tidak saling terhubung di ruang kerja** — Dua lemari kayu berdiri bersebelahan namun terkunci sendiri-sendiri sementara Dimas menenteng buku berkas dari satu meja ke meja lain.
  2. `[REMOTION · insert]` **Skema interoperabilitas satu data vs duplikasi formulir** — Diagram alur bersih membandingkan pengisian ulang berulang kali dengan arsitektur pertukaran data tunggal sekali isi.

## B04 · `SEQ_04/SCN_04` · `44.0s – 60.0s` (circular_domestic_callback)
- **Narasi VO (Bahasa Indonesia)**: Sore harinya kamu pulang ke kamar dengan satu tanda terima digital di ponsel dan setumpuk sisa fotokopi di tangan—pengingat bahwa transformasi digital sejati bukan soal mengganti kertas menjadi layar, melainkan memangkas kerumitan warga.
- **Dialog `char_dimas_citizen`** *(hela napas lega bercampur geli)*: "Setidaknya sisa fotokopinya masih berguna buat ganjal kaki meja."
- **Catatan Humor Situasional**: Callback ke adegan pembuka: map plastik biru akhirnya dipakai menjadi alas cangkir di meja belajar.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · medium]` **Dimas meletakkan buku berkas di meja belajar kamar saat sore** — Dimas masuk kembali lewat pintu kayu kamar lalu meletakkan map dokumen di samping lampu meja yang menyala hangat.
  2. `[BLENDER · establishing]` **Kamar diorama utuh dengan kasur, jendela, dan jam dinding** — Kamera menarik mundur memperlihatkan Dimas rebahan santai di kasur yang sama seperti pembuka video sementara jarum jam dinding menunjuk pukul lima sore.

