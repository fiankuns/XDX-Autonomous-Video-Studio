# Rencana Eksekusi Hybrid v3.4 — `audit_satir_sosial_ref001_60s`

> **GERBANG PERSETUJUAN WAJIB (`WAITING_APPROVAL`)**: Dilarang menjalankan mutasi scene Blender, sintesis TTS, atau render sebelum pengguna memberikan perintah persetujuan terstruktur yang sah.

- **Total Durasi**: `60.0s` (`1800 frame @ 30 fps`)
- **Jumlah Hierarchy**: `4 Sequence` · `4 Scene` · `4 Beat` · `18 Shot`

## Tabel Routing Shot & Handle Transisi
| Shot | Beat | Frame `[start, end)` | Durasi | Engine Utama | Transisi Masuk | Render Frames (termasuk Handle) |
|---|---|---|---:|---|---|---:|
| S001 | B01 | `[0, 90)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S002 | B01 | `[90, 180)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S003 | B01 | `[180, 270)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S004 | B01 | `[270, 360)` | 3.00s | `blender` | `trans_hard_cut_zero` | 102 |
| S005 | B02 | `[360, 438)` | 2.60s | `threejs` | `trans_cross_dissolve_12f` | 90 |
| S006 | B02 | `[438, 515)` | 2.57s | `threejs` | `trans_hard_cut_zero` | 77 |
| S007 | B02 | `[515, 600)` | 2.83s | `blender` | `trans_hard_cut_zero` | 85 |
| S008 | B02 | `[600, 685)` | 2.83s | `blender` | `trans_hard_cut_zero` | 91 |
| S009 | B02 | `[685, 763)` | 2.60s | `threejs` | `trans_whip_pan_cutaway_6f` | 84 |
| S010 | B02 | `[763, 840)` | 2.57s | `threejs` | `trans_hard_cut_zero` | 89 |
| S011 | B03 | `[840, 960)` | 4.00s | `blender` | `trans_cross_dissolve_12f` | 132 |
| S012 | B03 | `[960, 1080)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S013 | B03 | `[1080, 1200)` | 4.00s | `remotion` | `trans_hard_cut_zero` | 120 |
| S014 | B03 | `[1200, 1320)` | 4.00s | `remotion` | `trans_hard_cut_zero` | 132 |
| S015 | B04 | `[1320, 1440)` | 4.00s | `blender` | `trans_cross_dissolve_12f` | 132 |
| S016 | B04 | `[1440, 1560)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S017 | B04 | `[1560, 1680)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S018 | B04 | `[1680, 1800)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |

