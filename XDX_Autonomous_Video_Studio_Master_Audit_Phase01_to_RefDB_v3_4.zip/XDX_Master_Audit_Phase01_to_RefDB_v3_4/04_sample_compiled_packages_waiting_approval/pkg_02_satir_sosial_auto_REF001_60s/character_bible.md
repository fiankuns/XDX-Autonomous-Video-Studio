# Character Bible — Paradoks Layanan Tanpa Kertas: Mengapa Aplikasi Publik Masih Minta Fotokopi?

- **Catatan Sejarah & Biografi**: Seluruh karakter dan adegan instansi adalah fiksi satir ilustratif; tidak menyalin tokoh nyata.

## Daftar Karakter Produksi
### `char_dimas_citizen` — Dimas (`hero`)
- **Siluet & Proporsi**: Kepala bulat proporsi 0.34 tinggi tubuh, postur warga komuter sehari-hari yang ekspresif.
- **Pakaian & Properti Melekat**: Jaket kasual zaitun di atas kaus krem dan celana panjang abu gelap.
- **Palet Warna**: `#F3D6B6, #4D7C0F, #1E293B`
- **Spesifikasi Rig**: `xdx_diorama_humanoid_v1_ik_hands_feet`
- **Batas Representasi**: Karakter warga fiksi orisinal XDX Studio; tidak menyalin karakter sumber referensi.

### `char_sari_clerk` — Sari (`supporting`)
- **Siluet & Proporsi**: Postur rapi duduk tegak dengan kacamata persegi tipis dan gestur tangan prosedural.
- **Pakaian & Properti Melekat**: Kemeja kerja putih bersih dengan rompi biru tua dan tanda pengenal polos.
- **Palet Warna**: `#F3D6B6, #F8FAFC, #1E3A8A`
- **Spesifikasi Rig**: `xdx_diorama_humanoid_v1_ik_hands_feet`
- **Batas Representasi**: Karakter petugas fiksi orisinal XDX Studio.

