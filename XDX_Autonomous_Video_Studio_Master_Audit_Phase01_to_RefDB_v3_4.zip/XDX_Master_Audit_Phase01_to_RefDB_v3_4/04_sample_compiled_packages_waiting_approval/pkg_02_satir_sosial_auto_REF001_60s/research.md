# Dossier Riset Terverifikasi — Paradoks Layanan Tanpa Kertas: Mengapa Aplikasi Publik Masih Minta Fotokopi?

- **Genre Aktif**: `satir_sosial, storytelling`
- **Status Riset**: `VERIFIED_COMPLETE` (`hybrid_factual_satire`)
- **Rasio Cakupan Sitasi Terukur**: `100.0%` (2/2 klaim, 0 sumber unik)

## Ringkasan Kajian
Satir sosial orisinal mengenai fragmentasi aplikasi layanan publik dan pentingnya interoperabilitas data berdasarkan kajian OECD Digital Government dan UN E-Government Survey.

## Klaim Faktual & Sumber Primer/Institusional
- **`CLM_01` [verified_fact]**: Transformasi pemerintahan digital yang efektif menuntut prinsip once-only dan interoperabilitas lintas instansi agar warga tidak dibebani penyerahan dokumen berulang.
  - Sumber: *OECD — Recommendation of the Council on Digital Government Strategies* (2014) — https://legalinstruments.oecd.org/en/instruments/OECD-LEGAL-0406
- **`CLM_02` [verified_fact]**: Fragmentasi ribuan aplikasi sektoral tanpa integrasi proses bisnis belakang layar menyebabkan duplikasi prosedur administratif bagi pengguna layanan publik.
  - Sumber: *United Nations DESA — UN E-Government Survey: Accelerating Digital Transformation* (2024) — https://publicadministration.un.org/egovkb/en-us/Reports/UN-E-Government-Survey-2024

