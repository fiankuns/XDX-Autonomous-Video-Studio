# Naskah Produksi Siap Baca (VO, Dialog & Aksi Konkret) — Mengapa Waktu Terasa Melambat Saat Kita Panik? Dari Menara Jatuh Bebas hingga Jam Atom

## B01 · `SEQ_01/SCN_01` · `0.0s – 12.0s` (hook_visual_anomaly)
- **Narasi VO (Bahasa Indonesia)**: Pernahkah kamu menyenggol gelas kopi di pinggir meja, lalu tiba-tiba seluruh ruangan terasa melambat seperti adegan film laga, padahal jarum jam dinding tetap berdetak normal?
- **Dialog `char_raka_protagonist`** *(panik tertahan dengan mata membelalak)*: "Tunggu dulu, kenapa kopinya melayang lama sekali?!"
- **Catatan Humor Situasional**: Kontras dramatis wajah panik Raka terhadap insiden sepele gelas miring tiga derajat.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · establishing]` **Siku Raka dan cangkir kopi di tepi meja kayu jati** — Siku kanan Raka menyenggol gagang cangkir keramik di atas meja belajar hingga cangkir miring melewati bibir meja.
  2. `[BLENDER · close_up]` **Wajah Raka dan pantulan tetesan kopi** — Kamera mendorong mendekat ke wajah Raka yang membeku sementara jarum detik jam dinding di latar belakang bergeser satu klik tegas.
  3. `[THREEJS · insert]` **Insert jarum jam dinding berdetak presisi** — Jarum menit dan detik pada jam dinding berbingkai gelap bergetar halus tepat satu detik tanpa melambat sedikit pun.

## B02 · `SEQ_01/SCN_01` · `12.0s – 24.0s` (core_scientific_question)
- **Narasi VO (Bahasa Indonesia)**: Selama puluhan tahun banyak orang yakin otak manusia benar-benar mempercepat kecepatan rekam matanya saat terancam, mirip kamera berkecepatan tinggi.
- **Dialog `char_naya_researcher`** *(datar menyindir sambil menunjuk meja)*: "Kalau matamu secepat kamera sinema, harusnya gelas itu sudah ketangkap dari tadi."
- **Catatan Humor Situasional**: Naya menyodorkan buku catatan tebal tepat ketika Raka baru saja menangkap tatakan gelas.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · medium]` **Naya berdiri di ambang pintu kayu kamar sambil memegang buku** — Pintu kayu kamar terbuka dan Naya melangkah masuk sambil mengangkat buku catatan bersampul merah ke arah meja Raka.
  2. `[THREEJS · cutaway]` **Diagram perbandingan frame kamera cepat vs persepsi mata** — Dua kolom pedestal tiga dimensi tumbuh berdampingan membandingkan hipotesis frame mata cepat dengan kecepatan baca aktual retina.
  3. `[BLENDER · reaction]` **Reaksi Raka melirik buku di atas meja** — Raka menarik kursi belajarnya lalu mencondongkan badan memeriksa halaman diagram di buku Naya di bawah cahaya lampu meja.

## B03 · `SEQ_02/SCN_02` · `24.0s – 38.0s` (eagleman_tower_experiment_setup)
- **Narasi VO (Bahasa Indonesia)**: Pada tahun dua ribu tujuh, ahli saraf David Eagleman bersama Chess Stetson dan Matthew Fiesta menguji klaim ini secara ekstrem: menjatuhkan relawan telentang dari menara setinggi empat puluh delapan meter.
- **Catatan Humor Situasional**: Miniatur menara uji di atas meja tampak menjulang melewati kap lampu belajar.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · wide]` **Diorama menara jatuh bebas setinggi 48 meter** — Model bangunan menara uji vertikal muncul secara terukur lengkap dengan jaring pengaman di dasar dan penanda tinggi empat puluh delapan meter.
  2. `[REMOTION · insert]` **Kartu publikasi ilmiah tahun 2007 di timeline** — Pita tahun bergeser ke angka dua ribu tujuh menampilkan parameter eksperimen jatuh bebas menuju jaring tanpa beban tali pengikat.
  3. `[THREEJS · medium]` **Pohon penanda skala di samping dasar menara** — Kamera bergerak turun dari puncak menara melewati tajuk pohon rindang dan mobil parkir miniatur untuk memperlihatkan betapa tingginya jarak jatuh.

## B04 · `SEQ_02/SCN_02` · `38.0s – 51.0s` (perceptual_chronometer_test)
- **Narasi VO (Bahasa Indonesia)**: Di pergelangan tangan peserta dipasang kronometer persepsi dengan angka LED yang berkedip sedikit terlalu cepat untuk dibaca saat tenang. Jika otak sungguh melambat, angka itu pasti terbaca jelas saat jatuh.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · insert]` **Jam pergelangan kronometer LED berkedip cepat** — Kamera makro menyorot layar kronometer bundar di pergelangan tangan saat pola angka berganti cepat membentuk kilau buram yang tak terbaca.
  2. `[BLENDER · medium]` **Raka mempraktikkan menatap pergelangan tangannya sambil mundur ke kasur** — Raka merebahkan punggung secara teatrikal ke atas kasur kamar sambil mengangkat pergelangan tangannya tepat di depan wajah.
  3. `[REMOTION · cutaway]` **Grafik hasil bacaan akurasi jatuh vs berdiri di tanah** — Grafik batang animasi menampilkan tingkat keterbacaan angka saat jatuh bebas yang sejajar dan tidak melebihi kontrol di permukaan tanah.

## B05 · `SEQ_02/SCN_02` · `51.0s – 63.0s` (experiment_paradox_reveal)
- **Narasi VO (Bahasa Indonesia)**: Hasilnya mengejutkan: tak satu pun peserta mampu membaca angka berkedip lebih baik saat jatuh. Namun ketika diminta menaksir durasi jatuhnya sendiri, mereka rata-rata merasa jatuh tiga puluh enam persen lebih lama!
- **Dialog `char_raka_protagonist`** *(heran bercampur geli)*: "Jadi mata kita gagal baca angkanya, tapi otak tetap ngotot durasinya panjang?"
- **Catatan Humor Situasional**: Raka bangkit dari kasur dengan ekspresi merasa baru jatuh lima menit padahal baru dua detik.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · cutaway]` **Perbandingan durasi estimasi 36 persen lebih panjang** — Kolom kuning bertuliskan estimasi memori peserta tumbuh tiga puluh enam persen lebih tinggi dibanding kolom biru durasi jatuh sesungguhnya.
  2. `[BLENDER · medium]` **Raka duduk di tepi kasur menatap Naya** — Raka bangkit duduk di tepi kasur berlapis selimut biru sambil merentangkan kedua telapak tangan menunjukkan ukuran waktu yang membengkak.
  3. `[BLENDER · wide]` **Naya menunjuk lemari arsip buku di sudut kamar** — Naya membuka pintu lemari kayu di sudut ruangan dan menarik setumpuk buku tebal untuk menganalogikan kepadatan rekaman memori.

## B06 · `SEQ_03/SCN_03` · `63.0s – 76.0s` (amygdala_memory_density_mechanism)
- **Narasi VO (Bahasa Indonesia)**: Kuncinya ada pada amigdala. Riset neurobiologi James McGaugh menunjukkan bahwa saat darurat, amigdala memicu perekaman detail ingatan yang jauh lebih padat—dari bunyi gesekan baju sampai bayangan cahaya di jendela.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · insert]` **Tumpukan buku tipis vs buku catatan tebal di atas meja** — Di atas meja kayu, satu buku tipis mewakili ingatan detik biasa sementara lima buku tebal bertumpuk mewakili ingatan detik darurat.
  2. `[BLENDER · medium]` **Cahaya sore menembus kisi jendela kamar** — Berkas cahaya hangat masuk melalui kaca jendela berbingkai putih menyinari butiran debu halus yang tampak jelas di sekitar meja.
  3. `[REMOTION · cutaway]` **Skema alur pemutaran ulang memori retrospektif** — Diagram alir animasi memperlihatkan bahwa ilusi gerak lambat muncul saat otak membaca ulang arsip ingatan tebal, bukan saat peristiwa berlangsung.

## B07 · `SEQ_04/SCN_04` · `76.0s – 90.0s` (historical_biography_john_harrison)
- **Narasi VO (Bahasa Indonesia)**: Ketidakmampuan manusia menakar waktu secara konsisten inilah yang dulu mencelakai pelaut. Pada abad kedelapan belas, tukang kayu otodidak Inggris bernama John Harrison menghabiskan puluhan tahun merancang kronometer laut H-Empat.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · establishing]` **Ruang arsip sejarah dengan meja kayu tua dan lampu baca** — Transisi larut membuka ruang studi arsip berpalet hangat tempat buku kronik abad kedelapan belas dan jam bundar mekanis diletakkan di meja.
  2. `[BLENDER · medium]` **Karakter perajin sejarah memeriksa jam mekanis di meja kerja** — Figur rekonstruksi perajin membungkuk dengan teliti di kursi kayu sambil menyetel jarum jam bundar di samping lemari naskah.
  3. `[REMOTION · insert]` **Kartu tahun 1759 kronometer laut H4** — Penanda tahun seribu tujuh ratus lima puluh sembilan menyoroti pencapaian kronometer laut H-Empat menjaga akurasi penentuan garis bujur pelayaran.

## B08 · `SEQ_04/SCN_04` · `90.0s – 102.0s` (atomic_second_standard_bipm)
- **Narasi VO (Bahasa Indonesia)**: Kini manusia tidak lagi mengandalkan perasaan atau pegas logam semata. Satu detik resmi didefinisikan dari lebih sembilan miliar getaran radiasi transisi atom Sesium seratus tiga puluh tiga.
- **Catatan Humor Situasional**: Kontras antara sembilan miliar getaran atom per detik dan Raka yang terlambat bangun lima belas menit.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · cutaway]` **Visualisasi gelombang osilasi presisi 9.192.631.770 siklus** — Partikel bercahaya berosilasi secara teratur di atas panggung gelap menampilkan angka resmi sembilan miliar seratus sembilan puluh dua juta getaran per detik.
  2. `[REMOTION · insert]` **Perbandingan presisi jam mekanis ke standar atom SI** — Skala lini masa merentang dari jam saku abad kedelapan belas menuju standar atom modern yang menjadi acuan satelit navigasi.
  3. `[BLENDER · wide]` **Jam dinding dan jendela ruang arsip** — Kamera bergerak menyamping melewati jendela ruang arsip kembali mengarah ke pintu penghubung menuju masa kini.

## B09 · `SEQ_05/SCN_05` · `102.0s – 114.0s` (everyday_indonesian_contrast)
- **Narasi VO (Bahasa Indonesia)**: Efek kepadatan memori ini juga menjawab teka-teki klasik sehari-hari: kenapa menunggu lampu merah satu menit saat kebelet terasa abadi, sedangkan bermain ponsel satu jam lenyap tanpa jejak?
- **Catatan Humor Situasional**: Mobil biru miniatur berhenti tepat di depan pohon sementara pengemudinya menatap jam raksasa.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · wide]` **Mobil miniatur tertahan di jalan dekat bangunan dan pohon** — Sebuah kendaraan biru berhenti di tepi jalan miniatur di depan bangunan toko dan pohon peneduh sementara lampu depannya menyala hangat.
  2. `[BLENDER · medium]` **Raka bersandar malas di kursi belajarnya** — Di dalam kamar, Raka bersandar santai di kursi kayu sambil mengetuk-ngetuk jari ke permukaan meja dengan ekspresi bengong tanpa beban.
  3. `[REMOTION · cutaway]` **Perbandingan kepadatan jejak memori baru vs rutinitas** — Dua grafik garis bergerak kontras memperlihatkan betapa tipisnya catatan memori saat aktivitas pasif berulang dibanding momen penuh kejutan.

## B10 · `SEQ_05/SCN_05` · `114.0s – 126.0s` (absurd_escalation_experiment_at_home)
- **Narasi VO (Bahasa Indonesia)**: Mendengar penjelasan itu, Raka langsung menyimpulkan ide konyol: kalau ingin akhir pekan terasa dua kali lebih panjang, berarti ia harus mengisi kamarnya dengan kejutan baru setiap sepuluh menit!
- **Dialog `char_raka_protagonist`** *(antusias penuh percaya diri yang absurd)*: "Berarti kalau aku kaget terus tiap jam, hari Minggu kita jadi serasa empat hari!"
- **Dialog `char_naya_researcher`** *(datar menahan tawa)*: "Itu namanya uji nyali jantung, Raka, bukan liburan akhir pekan."
- **Catatan Humor Situasional**: Raka menata lampu, buku, dan jam dinding secara berlebihan demi memancing kejutan amigdala.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · medium]` **Raka berdiri antusias di samping meja dan lampu belajar** — Raka berdiri tegak dari kursinya sambil mengangkat satu jari penuh semangat ke arah jam dinding dan tumpukan buku di meja.
  2. `[BLENDER · reaction]` **Naya menggeleng pelan di dekat pintu dan lemari** — Naya menyilangkan tangan di dekat lemari kayu sambil menatap Raka dengan alis terangkat sebelah.
  3. `[THREEJS · insert]` **Close-up lampu meja menyala terang menyinari buku** — Cahaya hangat dari kap lampu meja menyorot halaman buku terbuka yang memuat rangkuman cara sehat memperkaya memori.

## B11 · `SEQ_06/SCN_06` · `126.0s – 138.0s` (practical_takeaway_novelty)
- **Narasi VO (Bahasa Indonesia)**: Tanpa perlu terjun dari menara, prinsipnya tetap sama: mencoba rute jalan baru, membaca topik asing, dan memberi perhatian penuh membuat otak menulis lebih banyak kenangan sehingga hidup tidak terasa melesat begitu saja.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · wide]` **Pemandangan luar jendela memperlihatkan jalan, pohon, dan bangunan** — Kamera bergerak melewati bingkai jendela kamar menatap jalan lingkungan yang teduh oleh pohon hijau dan deretan bangunan.
  2. `[REMOTION · cutaway]` **Tiga poin ringkasan memori kaya vs rutinitas otomatis** — Kartu tipografi bersih merangkum tiga pemicu ingatan bermakna: hal baru, perhatian utuh, dan variasi pengalaman harian.
  3. `[BLENDER · medium]` **Raka mencatat di buku sambil tersenyum tenang** — Raka duduk kembali di kursi belajar dan meletakkan buku catatan dengan rapi di samping lampu meja yang bercahaya lembut.

## B12 · `SEQ_06/SCN_06` · `138.0s – 150.0s` (payoff_callback_loop)
- **Narasi VO (Bahasa Indonesia)**: Jadi lain kali saat gelas kopimu tersenggol di meja, ingatlah: jam dinding tidak pernah melambat—otakmulah yang sedang sibuk memotret setiap detiknya agar kamu tak mengulangi kesalahan yang sama.
- **Dialog `char_raka_protagonist`** *(lega dan puas)*: "Aman. Sekarang jaraknya tiga puluh sentimeter dari pinggir meja."
- **Catatan Humor Situasional**: Callback ke cangkir di awal video: kali ini Raka menggeser cangkir ke tengah meja dengan penggaris.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · close_up]` **Tangan Raka menggeser cangkir menjauh dari tepi meja** — Raka mendorong perlahan cangkir keramik ke bagian tengah meja kayu jauh dari jangkauan sikunya sambil melirik jam dinding.
  2. `[BLENDER · establishing]` **Raka dan Naya di ruang kamar diorama utuh** — Kamera menarik mundur menampilkan keseluruhan diorama kamar berlampu hangat dengan kasur, lemari, meja, jendela, dan pintu kayu saat jarum jam berdetak stabil.

