# Rencana Eksekusi Hybrid v3.4 — `audit_multiref_150s`

> **GERBANG PERSETUJUAN WAJIB (`WAITING_APPROVAL`)**: Dilarang menjalankan mutasi scene Blender, sintesis TTS, atau render sebelum pengguna memberikan perintah persetujuan terstruktur yang sah.

- **Total Durasi**: `150.0s` (`4500 frame @ 30 fps`)
- **Jumlah Hierarchy**: `6 Sequence` · `6 Scene` · `12 Beat` · `48 Shot`

## Tabel Routing Shot & Handle Transisi
| Shot | Beat | Frame `[start, end)` | Durasi | Engine Utama | Transisi Masuk | Render Frames (termasuk Handle) |
|---|---|---|---:|---|---|---:|
| S001 | B01 | `[0, 120)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S002 | B01 | `[120, 240)` | 4.00s | `blender` | `trans_hard_cut_zero` | 126 |
| S003 | B01 | `[240, 360)` | 4.00s | `threejs` | `trans_whip_pan_cutaway_6f` | 126 |
| S004 | B02 | `[360, 426)` | 2.20s | `blender` | `trans_hard_cut_zero` | 66 |
| S005 | B02 | `[426, 492)` | 2.20s | `blender` | `trans_hard_cut_zero` | 72 |
| S006 | B02 | `[492, 612)` | 4.00s | `threejs` | `trans_whip_pan_cutaway_6f` | 126 |
| S007 | B02 | `[612, 720)` | 3.60s | `blender` | `trans_hard_cut_zero` | 120 |
| S008 | B03 | `[720, 799)` | 2.63s | `threejs` | `trans_cross_dissolve_12f` | 91 |
| S009 | B03 | `[799, 878)` | 2.63s | `threejs` | `trans_hard_cut_zero` | 79 |
| S010 | B03 | `[878, 944)` | 2.20s | `remotion` | `trans_hard_cut_zero` | 66 |
| S011 | B03 | `[944, 1009)` | 2.17s | `remotion` | `trans_hard_cut_zero` | 65 |
| S012 | B03 | `[1009, 1075)` | 2.20s | `threejs` | `trans_hard_cut_zero` | 66 |
| S013 | B03 | `[1075, 1140)` | 2.17s | `threejs` | `trans_hard_cut_zero` | 71 |
| S014 | B04 | `[1140, 1266)` | 4.20s | `threejs` | `trans_whip_pan_cutaway_6f` | 132 |
| S015 | B04 | `[1266, 1335)` | 2.30s | `blender` | `trans_hard_cut_zero` | 69 |
| S016 | B04 | `[1335, 1404)` | 2.30s | `blender` | `trans_hard_cut_zero` | 69 |
| S017 | B04 | `[1404, 1530)` | 4.20s | `remotion` | `trans_hard_cut_zero` | 132 |
| S018 | B05 | `[1530, 1650)` | 4.00s | `threejs` | `trans_whip_pan_cutaway_6f` | 126 |
| S019 | B05 | `[1650, 1770)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S020 | B05 | `[1770, 1890)` | 4.00s | `blender` | `trans_hard_cut_zero` | 126 |
| S021 | B06 | `[1890, 1962)` | 2.40s | `threejs` | `trans_whip_pan_cutaway_6f` | 78 |
| S022 | B06 | `[1962, 2033)` | 2.37s | `threejs` | `trans_hard_cut_zero` | 71 |
| S023 | B06 | `[2033, 2098)` | 2.17s | `blender` | `trans_hard_cut_zero` | 65 |
| S024 | B06 | `[2098, 2163)` | 2.17s | `blender` | `trans_hard_cut_zero` | 65 |
| S025 | B06 | `[2163, 2280)` | 3.90s | `remotion` | `trans_hard_cut_zero` | 129 |
| S026 | B07 | `[2280, 2355)` | 2.50s | `blender` | `trans_cross_dissolve_12f` | 87 |
| S027 | B07 | `[2355, 2429)` | 2.47s | `blender` | `trans_hard_cut_zero` | 74 |
| S028 | B07 | `[2429, 2497)` | 2.27s | `blender` | `trans_hard_cut_zero` | 68 |
| S029 | B07 | `[2497, 2565)` | 2.27s | `blender` | `trans_hard_cut_zero` | 68 |
| S030 | B07 | `[2565, 2633)` | 2.27s | `remotion` | `trans_hard_cut_zero` | 68 |
| S031 | B07 | `[2633, 2700)` | 2.23s | `remotion` | `trans_hard_cut_zero` | 73 |
| S032 | B08 | `[2700, 2820)` | 4.00s | `threejs` | `trans_whip_pan_cutaway_6f` | 126 |
| S033 | B08 | `[2820, 2940)` | 4.00s | `remotion` | `trans_hard_cut_zero` | 120 |
| S034 | B08 | `[2940, 3060)` | 4.00s | `blender` | `trans_hard_cut_zero` | 132 |
| S035 | B09 | `[3060, 3126)` | 2.20s | `threejs` | `trans_cross_dissolve_12f` | 78 |
| S036 | B09 | `[3126, 3192)` | 2.20s | `threejs` | `trans_hard_cut_zero` | 66 |
| S037 | B09 | `[3192, 3312)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S038 | B09 | `[3312, 3420)` | 3.60s | `remotion` | `trans_hard_cut_zero` | 108 |
| S039 | B10 | `[3420, 3540)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S040 | B10 | `[3540, 3660)` | 4.00s | `blender` | `trans_hard_cut_zero` | 126 |
| S041 | B10 | `[3660, 3780)` | 4.00s | `threejs` | `trans_whip_pan_cutaway_6f` | 126 |
| S042 | B11 | `[3780, 3900)` | 4.00s | `threejs` | `trans_hard_cut_zero` | 120 |
| S043 | B11 | `[3900, 4020)` | 4.00s | `remotion` | `trans_hard_cut_zero` | 120 |
| S044 | B11 | `[4020, 4140)` | 4.00s | `blender` | `trans_hard_cut_zero` | 120 |
| S045 | B12 | `[4140, 4230)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S046 | B12 | `[4230, 4320)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S047 | B12 | `[4320, 4410)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |
| S048 | B12 | `[4410, 4500)` | 3.00s | `blender` | `trans_hard_cut_zero` | 90 |

