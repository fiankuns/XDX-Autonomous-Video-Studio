# Dossier Riset Terverifikasi — Mengapa Waktu Terasa Melambat Saat Kita Panik? Dari Menara Jatuh Bebas hingga Jam Atom

- **Genre Aktif**: `explainer`
- **Status Riset**: `VERIFIED_COMPLETE` (`factual_verified`)
- **Rasio Cakupan Sitasi Terukur**: `100.0%` (4/4 klaim, 4 sumber unik)

## Ringkasan Kajian
Kajian neurosains persepsi waktu (Stetson, Fiesta & Eagleman 2007; McGaugh 2004) yang dipadukan dengan sejarah kronometer laut John Harrison H4 (1759) dan definisi detik atom Sesium-133 BIPM.

## Klaim Faktual & Sumber Primer/Institusional
- **`CLM_01` [peer_reviewed_study]**: Eksperimen jatuh bebas setinggi 48 meter dengan kronometer persepsi LED membuktikan bahwa resolusi temporal visual tidak meningkat saat ketakutan akut, namun peserta menaksir durasi jatuh mereka sekitar 36% lebih lama secara retrospektif.
  - Sumber: *Stetson C., Fiesta M.P., Eagleman D.M. — Does Time Really Slow Down during a Frightening Event? (PLoS ONE)* (2007) — https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0001295
- **`CLM_02` [peer_reviewed_study]**: Aktivasi amigdala selama peristiwa bermuatan emosi memodulasi konsolidasi memori episodik yang lebih padat sehingga rekaman ingatan terasa lebih panjang saat diingat kembali.
  - Sumber: *McGaugh J.L. — The Amygdala Modulates the Consolidation of Memories of Emotionally Arousing Experiences (Annual Review of Neuroscience)* (2004) — https://www.annualreviews.org/content/journals/10.1146/annurev.neuro.27.070203.144157
- **`CLM_03` [archival_historical_record]**: John Harrison menyelesaikan kronometer laut H4 pada tahun 1759 untuk menjaga ketepatan waktu di laut dan memecahkan masalah penentuan garis bujur pelayaran.
  - Sumber: *Royal Museums Greenwich — John Harrison and the Longitude Problem* (2023) — https://www.rmg.co.uk/stories/topics/john-harrison-and-longitude-problem
- **`CLM_04` [verified_fact]**: Satu detik dalam Sistem Satuan Internasional (SI) didefinisikan secara eksak melalui 9.192.631.770 periode radiasi transisi hiperhalus atom Sesium-133 pada keadaan dasar.
  - Sumber: *Bureau International des Poids et Mesures (BIPM) — SI Base Unit: second (s)* (2019) — https://www.bipm.org/en/si-base-units/second

