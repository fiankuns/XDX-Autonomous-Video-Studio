# Character Bible — Mengapa Waktu Terasa Melambat Saat Kita Panik? Dari Menara Jatuh Bebas hingga Jam Atom

- **Catatan Sejarah & Biografi**: Segmen John Harrison 1759 disajikan sebagai rekonstruksi diorama orisinal, bukan rekaman arsip langsung.

## Daftar Karakter Produksi
### `char_raka_protagonist` — Raka (`hero`)
- **Siluet & Proporsi**: Kepala bulat proporsi 0.34 tinggi tubuh, bahu ringkas, ekspresi alis dan kelopak mata sangat kontras.
- **Pakaian & Properti Melekat**: Kemeja kerja biru gulung lengan di atas kaus putih dan celana panjang gelap.
- **Palet Warna**: `#F4D8B8, #2563EB, #1E293B`
- **Spesifikasi Rig**: `xdx_diorama_humanoid_v1_ik_hands_feet`
- **Batas Representasi**: Karakter fiksi orisinal XDX Studio; tidak merepresentasikan individu nyata.

### `char_naya_researcher` — Naya (`supporting`)
- **Siluet & Proporsi**: Siluet ramping dengan kacamata bundar tipis dan postur tegak tenang.
- **Pakaian & Properti Melekat**: Jaket kardigan kuning hangat dengan rok/celana abu tua dan buku catatan merah.
- **Palet Warna**: `#F4D8B8, #D97706, #334155`
- **Spesifikasi Rig**: `xdx_diorama_humanoid_v1_ik_hands_feet`
- **Batas Representasi**: Karakter fiksi orisinal XDX Studio; segmen perajin 1759 adalah rekonstruksi ilustratif.

