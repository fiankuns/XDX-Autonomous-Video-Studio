# Naskah Produksi Siap Baca (VO, Dialog & Aksi Konkret) — Mengapa Waktu Terasa Melambat Saat Kita Panik? Dari Menara Jatuh Bebas hingga Jam Atom

## B01 · `SEQ_01/SCN_01` · `0.0s – 7.2s` (hook_visual_anomaly)
- **Narasi VO (Bahasa Indonesia)**: Pernahkah kamu menyenggol gelas kopi di pinggir meja, lalu tiba-tiba seluruh ruangan terasa melambat seperti adegan film laga, padahal jarum jam dinding tetap berdetak normal?
- **Dialog `char_raka_protagonist`** *(panik tertahan dengan mata membelalak)*: "Tunggu dulu, kenapa kopinya melayang lama sekali?!"
- **Catatan Humor Situasional**: Kontras dramatis wajah panik Raka terhadap insiden sepele gelas miring tiga derajat.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · establishing]` **Siku Raka dan cangkir kopi di tepi meja kayu jati** — Siku kanan Raka menyenggol gagang cangkir keramik di atas meja belajar hingga cangkir miring melewati bibir meja.
  2. `[BLENDER · close_up]` **Wajah Raka dan pantulan tetesan kopi** — Kamera mendorong mendekat ke wajah Raka yang membeku sementara jarum detik jam dinding di latar belakang bergeser satu klik tegas.
  3. `[THREEJS · insert]` **Insert jarum jam dinding berdetak presisi** — Jarum menit dan detik pada jam dinding berbingkai gelap bergetar halus tepat satu detik tanpa melambat sedikit pun.

## B02 · `SEQ_01/SCN_01` · `7.2s – 14.4s` (core_scientific_question)
- **Narasi VO (Bahasa Indonesia)**: Selama puluhan tahun banyak orang yakin otak manusia benar-benar mempercepat kecepatan rekam matanya saat terancam, mirip kamera berkecepatan tinggi.
- **Dialog `char_naya_researcher`** *(datar menyindir sambil menunjuk meja)*: "Kalau matamu secepat kamera sinema, harusnya gelas itu sudah ketangkap dari tadi."
- **Catatan Humor Situasional**: Naya menyodorkan buku catatan tebal tepat ketika Raka baru saja menangkap tatakan gelas.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · medium]` **Naya berdiri di ambang pintu kayu kamar sambil memegang buku** — Pintu kayu kamar terbuka dan Naya melangkah masuk sambil mengangkat buku catatan bersampul merah ke arah meja Raka.
  2. `[THREEJS · cutaway]` **Diagram perbandingan frame kamera cepat vs persepsi mata** — Dua kolom pedestal tiga dimensi tumbuh berdampingan membandingkan hipotesis frame mata cepat dengan kecepatan baca aktual retina.
  3. `[BLENDER · reaction]` **Reaksi Raka melirik buku di atas meja** — Raka menarik kursi belajarnya lalu mencondongkan badan memeriksa halaman diagram di buku Naya di bawah cahaya lampu meja.

## B03 · `SEQ_02/SCN_02` · `14.4s – 22.8s` (eagleman_tower_experiment_setup)
- **Narasi VO (Bahasa Indonesia)**: Pada tahun dua ribu tujuh, ahli saraf David Eagleman bersama Chess Stetson dan Matthew Fiesta menguji klaim ini secara ekstrem: menjatuhkan relawan telentang dari menara setinggi empat puluh delapan meter.
- **Catatan Humor Situasional**: Miniatur menara uji di atas meja tampak menjulang melewati kap lampu belajar.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · wide]` **Diorama menara jatuh bebas setinggi 48 meter** — Model bangunan menara uji vertikal muncul secara terukur lengkap dengan jaring pengaman di dasar dan penanda tinggi empat puluh delapan meter.
  2. `[REMOTION · insert]` **Kartu publikasi ilmiah tahun 2007 di timeline** — Pita tahun bergeser ke angka dua ribu tujuh menampilkan parameter eksperimen jatuh bebas menuju jaring tanpa beban tali pengikat.
  3. `[THREEJS · medium]` **Pohon penanda skala di samping dasar menara** — Kamera bergerak turun dari puncak menara melewati tajuk pohon rindang dan mobil parkir miniatur untuk memperlihatkan betapa tingginya jarak jatuh.

## B04 · `SEQ_02/SCN_02` · `22.8s – 30.6s` (perceptual_chronometer_test)
- **Narasi VO (Bahasa Indonesia)**: Di pergelangan tangan peserta dipasang kronometer persepsi dengan angka LED yang berkedip sedikit terlalu cepat untuk dibaca saat tenang. Jika otak sungguh melambat, angka itu pasti terbaca jelas saat jatuh.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · insert]` **Jam pergelangan kronometer LED berkedip cepat** — Kamera makro menyorot layar kronometer bundar di pergelangan tangan saat pola angka berganti cepat membentuk kilau buram yang tak terbaca.
  2. `[BLENDER · medium]` **Raka mempraktikkan menatap pergelangan tangannya sambil mundur ke kasur** — Raka merebahkan punggung secara teatrikal ke atas kasur kamar sambil mengangkat pergelangan tangannya tepat di depan wajah.
  3. `[REMOTION · cutaway]` **Grafik hasil bacaan akurasi jatuh vs berdiri di tanah** — Grafik batang animasi menampilkan tingkat keterbacaan angka saat jatuh bebas yang sejajar dan tidak melebihi kontrol di permukaan tanah.

## B05 · `SEQ_02/SCN_02` · `30.6s – 37.8s` (experiment_paradox_reveal)
- **Narasi VO (Bahasa Indonesia)**: Hasilnya mengejutkan: tak satu pun peserta mampu membaca angka berkedip lebih baik saat jatuh. Namun ketika diminta menaksir durasi jatuhnya sendiri, mereka rata-rata merasa jatuh tiga puluh enam persen lebih lama!
- **Dialog `char_raka_protagonist`** *(heran bercampur geli)*: "Jadi mata kita gagal baca angkanya, tapi otak tetap ngotot durasinya panjang?"
- **Catatan Humor Situasional**: Raka bangkit dari kasur dengan ekspresi merasa baru jatuh lima menit padahal baru dua detik.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · cutaway]` **Perbandingan durasi estimasi 36 persen lebih panjang** — Kolom kuning bertuliskan estimasi memori peserta tumbuh tiga puluh enam persen lebih tinggi dibanding kolom biru durasi jatuh sesungguhnya.
  2. `[BLENDER · medium]` **Raka duduk di tepi kasur menatap Naya** — Raka bangkit duduk di tepi kasur berlapis selimut biru sambil merentangkan kedua telapak tangan menunjukkan ukuran waktu yang membengkak.
  3. `[BLENDER · wide]` **Naya menunjuk lemari arsip buku di sudut kamar** — Naya membuka pintu lemari kayu di sudut ruangan dan menarik setumpuk buku tebal untuk menganalogikan kepadatan rekaman memori.

## B06 · `SEQ_03/SCN_03` · `37.8s – 45.6s` (amygdala_memory_density_mechanism)
- **Narasi VO (Bahasa Indonesia)**: Kuncinya ada pada amigdala. Riset neurobiologi James McGaugh menunjukkan bahwa saat darurat, amigdala memicu perekaman detail ingatan yang jauh lebih padat—dari bunyi gesekan baju sampai bayangan cahaya di jendela.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · insert]` **Tumpukan buku tipis vs buku catatan tebal di atas meja** — Di atas meja kayu, satu buku tipis mewakili ingatan detik biasa sementara lima buku tebal bertumpuk mewakili ingatan detik darurat.
  2. `[BLENDER · medium]` **Cahaya sore menembus kisi jendela kamar** — Berkas cahaya hangat masuk melalui kaca jendela berbingkai putih menyinari butiran debu halus yang tampak jelas di sekitar meja.
  3. `[REMOTION · cutaway]` **Skema alur pemutaran ulang memori retrospektif** — Diagram alir animasi memperlihatkan bahwa ilusi gerak lambat muncul saat otak membaca ulang arsip ingatan tebal, bukan saat peristiwa berlangsung.

## B07 · `SEQ_04/SCN_04` · `45.6s – 52.8s` (atomic_second_standard_bipm)
- **Narasi VO (Bahasa Indonesia)**: Kini manusia tidak lagi mengandalkan perasaan atau pegas logam semata. Satu detik resmi didefinisikan dari lebih sembilan miliar getaran radiasi transisi atom Sesium seratus tiga puluh tiga.
- **Catatan Humor Situasional**: Kontras antara sembilan miliar getaran atom per detik dan Raka yang terlambat bangun lima belas menit.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[THREEJS · cutaway]` **Visualisasi gelombang osilasi presisi 9.192.631.770 siklus** — Partikel bercahaya berosilasi secara teratur di atas panggung gelap menampilkan angka resmi sembilan miliar seratus sembilan puluh dua juta getaran per detik.
  2. `[REMOTION · insert]` **Perbandingan presisi jam mekanis ke standar atom SI** — Skala lini masa merentang dari jam saku abad kedelapan belas menuju standar atom modern yang menjadi acuan satelit navigasi.
  3. `[BLENDER · wide]` **Jam dinding dan jendela ruang arsip** — Kamera bergerak menyamping melewati jendela ruang arsip kembali mengarah ke pintu penghubung menuju masa kini.

## B08 · `SEQ_06/SCN_06` · `52.8s – 60.0s` (payoff_callback_loop)
- **Narasi VO (Bahasa Indonesia)**: Jadi lain kali saat gelas kopimu tersenggol di meja, ingatlah: jam dinding tidak pernah melambat—otakmulah yang sedang sibuk memotret setiap detiknya agar kamu tak mengulangi kesalahan yang sama.
- **Dialog `char_raka_protagonist`** *(lega dan puas)*: "Aman. Sekarang jaraknya tiga puluh sentimeter dari pinggir meja."
- **Catatan Humor Situasional**: Callback ke cangkir di awal video: kali ini Raka menggeser cangkir ke tengah meja dengan penggaris.
- **Rangkaian Aksi Visual Per-Shot**:
  1. `[BLENDER · close_up]` **Tangan Raka menggeser cangkir menjauh dari tepi meja** — Raka mendorong perlahan cangkir keramik ke bagian tengah meja kayu jauh dari jangkauan sikunya sambil melirik jam dinding.
  2. `[BLENDER · establishing]` **Raka dan Naya di ruang kamar diorama utuh** — Kamera menarik mundur menampilkan keseluruhan diorama kamar berlampu hangat dengan kasur, lemari, meja, jendela, dan pintu kayu saat jarum jam berdetak stabil.

