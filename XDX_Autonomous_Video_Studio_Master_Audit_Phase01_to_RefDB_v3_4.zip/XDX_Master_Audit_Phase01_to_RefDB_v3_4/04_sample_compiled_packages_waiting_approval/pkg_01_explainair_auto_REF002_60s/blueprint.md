# Universal Production Blueprint v3.4 — Mengapa Waktu Terasa Melambat Saat Kita Panik? Dari Menara Jatuh Bebas hingga Jam Atom

- **Genre Terpadu**: `explainer`
- **Profil Referensi Aktif (`reference_database`)**: `REF-002` (`hosted_3d_explainer_cutaway_v1`)
- **Target Durasi Master**: `60 detik`
- **Premis Utama**: Menjelaskan paradoks mengapa peristiwa mendebarkan terasa berjalan dalam gerak lambat bukan karena mata merekam lebih cepat, melainkan karena amigdala menyimpan ingatan lebih rapat.
- **Hook Visual (0–3s)**: Siku Raka menyenggol cangkir kopi di bibir meja kayu sementara jarum jam dinding tetap berdetak tegas.
- **Hook Lisan (0–3s)**: "Pernahkah kamu menyenggol gelas kopi di pinggir meja, lalu seluruh ruangan terasa melambat?"
- **Mekanisme Explainer**: Perbandingan kronometer LED jatuh bebas -> kepadatan memori amigdala -> standar waktu objektif.
- **Strategi Humor**: Kontras situasi keseharian kamar Indonesia (cangkir kopi & ide liburan kaget Raka) dengan eksperimen ilmiah serius.
- **Catatan Sejarah & Biografi**: Segmen John Harrison 1759 disajikan sebagai rekonstruksi diorama orisinal, bukan rekaman arsip langsung.
- **Payoff & Callback**: Raka menggeser cangkir kopi 30 sentimeter ke tengah meja sambil melirik jarum jam dinding.

## Story Arc Tiga Babak
1. **Act I (Setup & Anomali)**: Insiden cangkir kopi di meja kamar memicu pertanyaan apakah mata manusia mampu memperlambat waktu.
2. **Act II (Investigasi & Eskalasi)**: Uji jatuh bebas 48 meter Eagleman, peran amigdala, serta kontras sejarah kronometer H4 hingga jam atom Sesium.
3. **Act III (Klimaks & Callback)**: Kesimpulan konyol Raka diluruskan menjadi cara ilmiah memperkaya memori harian, ditutup callback pengamanan cangkir.

