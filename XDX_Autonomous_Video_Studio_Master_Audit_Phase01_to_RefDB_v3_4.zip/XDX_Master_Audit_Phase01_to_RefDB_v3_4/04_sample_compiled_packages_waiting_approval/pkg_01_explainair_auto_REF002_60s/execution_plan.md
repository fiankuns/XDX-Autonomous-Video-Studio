# Rencana Eksekusi Hybrid v3.4 — `audit_explainair_ref002_60s`

> **GERBANG PERSETUJUAN WAJIB (`WAITING_APPROVAL`)**: Dilarang menjalankan mutasi scene Blender, sintesis TTS, atau render sebelum pengguna memberikan perintah persetujuan terstruktur yang sah.

- **Total Durasi**: `60.0s` (`1800 frame @ 30 fps`)
- **Jumlah Hierarchy**: `5 Sequence` · `5 Scene` · `8 Beat` · `23 Shot`

## Tabel Routing Shot & Handle Transisi
| Shot | Beat | Frame `[start, end)` | Durasi | Engine Utama | Transisi Masuk | Render Frames (termasuk Handle) |
|---|---|---|---:|---|---|---:|
| S001 | B01 | `[0, 72)` | 2.40s | `blender` | `trans_hard_cut_zero` | 72 |
| S002 | B01 | `[72, 144)` | 2.40s | `blender` | `trans_hard_cut_zero` | 78 |
| S003 | B01 | `[144, 216)` | 2.40s | `threejs` | `trans_whip_pan_cutaway_6f` | 78 |
| S004 | B02 | `[216, 295)` | 2.63s | `blender` | `trans_hard_cut_zero` | 85 |
| S005 | B02 | `[295, 367)` | 2.40s | `threejs` | `trans_whip_pan_cutaway_6f` | 78 |
| S006 | B02 | `[367, 432)` | 2.17s | `blender` | `trans_hard_cut_zero` | 77 |
| S007 | B03 | `[432, 526)` | 3.13s | `threejs` | `trans_cross_dissolve_12f` | 106 |
| S008 | B03 | `[526, 605)` | 2.63s | `remotion` | `trans_hard_cut_zero` | 79 |
| S009 | B03 | `[605, 684)` | 2.63s | `threejs` | `trans_hard_cut_zero` | 85 |
| S010 | B04 | `[684, 760)` | 2.53s | `threejs` | `trans_whip_pan_cutaway_6f` | 82 |
| S011 | B04 | `[760, 843)` | 2.77s | `blender` | `trans_hard_cut_zero` | 83 |
| S012 | B04 | `[843, 918)` | 2.50s | `remotion` | `trans_hard_cut_zero` | 81 |
| S013 | B05 | `[918, 990)` | 2.40s | `threejs` | `trans_whip_pan_cutaway_6f` | 78 |
| S014 | B05 | `[990, 1062)` | 2.40s | `blender` | `trans_hard_cut_zero` | 72 |
| S015 | B05 | `[1062, 1134)` | 2.40s | `blender` | `trans_hard_cut_zero` | 78 |
| S016 | B06 | `[1134, 1220)` | 2.87s | `threejs` | `trans_whip_pan_cutaway_6f` | 92 |
| S017 | B06 | `[1220, 1298)` | 2.60s | `blender` | `trans_hard_cut_zero` | 78 |
| S018 | B06 | `[1298, 1368)` | 2.33s | `remotion` | `trans_hard_cut_zero` | 76 |
| S019 | B07 | `[1368, 1440)` | 2.40s | `threejs` | `trans_whip_pan_cutaway_6f` | 78 |
| S020 | B07 | `[1440, 1512)` | 2.40s | `remotion` | `trans_hard_cut_zero` | 72 |
| S021 | B07 | `[1512, 1584)` | 2.40s | `blender` | `trans_hard_cut_zero` | 72 |
| S022 | B08 | `[1584, 1692)` | 3.60s | `blender` | `trans_hard_cut_zero` | 108 |
| S023 | B08 | `[1692, 1800)` | 3.60s | `blender` | `trans_hard_cut_zero` | 108 |

